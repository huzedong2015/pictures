
const getGoogleData = () => {
  fetch("https://www.google.com", {
      method: "POST"
    })
      .then((res) => res.json())
      .then((res) => {
        console.log(res);
      })
}

document.getElementById("test1").addEventListener("click", getGoogleData);

// POST automatically changes to GET
document.getElementById("test2").addEventListener("click", () => {
  window.Asc.plugin.callCommand(() => {
    getGoogleData();
  });
});
document.getElementById("test1").addEventListener("click", () => {
  fetch("https://www.google.com", {
      method: "POST"
    });
});

// POST automatically changes to GET
document.getElementById("test2").addEventListener("click", () => {
  window.Asc.plugin.callCommand(() => {
    fetch("https://www.google.com", {
      method: "POST"
    });
  });
});